@extends('admin.layout.admin')
@section('content')
    <h3>Admin</h3>
@endsection