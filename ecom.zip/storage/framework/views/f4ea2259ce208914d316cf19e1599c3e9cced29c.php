
<?php $__env->startComponent('mail::message'); ?>

Hello,
You are receiving this email to Verify Your E-mail 



<?php $__env->startComponent('mail::button', ['url' => '#']); ?>

<a href="<?php echo e(route('sendingEmail',["email" => $user->email,
								"verifyToken" => $user->verifyToken])); ?>"> 

Verify E-mail
<?php echo $__env->renderComponent(); ?>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
