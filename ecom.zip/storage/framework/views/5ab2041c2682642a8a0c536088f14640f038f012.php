<?php

use App\admin\Category;
?>


<?php $__env->startSection('content'); ?>
<head>
	<link rel="stylesheet" href="<?php echo e(asset('css/table.css')); ?>">
</head>
<h3>Shirts Products</h3>
<table class="table" id="customers">
	<thead>
		<tr>
			<th>ID</th>
			<th >Name</th>
			<th>Description</th>
			<th >Size</th>
			<th>Price</th>
			<th>Backkground Image</th>
			<th>Category Name</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php $__empty_1 = true; $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td> <h4><?php echo e($shirt->id); ?></h4> </td>
				<td> <h4><?php echo e($shirt->name); ?></h4> </td>	
				<td> <h4><?php echo e($shirt->description); ?></h4> </td>
				<td> <h4><?php echo e($shirt->size); ?></h4> </td>
				<td> <h4><?php echo e($shirt->price); ?> </h4> </td>
				<td> <img class="img-responsive" src="/storage/photos/shirts/<?php echo e($shirt->image); ?>"></td>

				<td> <h4>
					<?php $cate = Category::find($shirt->category_id);
					?>
					<?php echo e($cate->name); ?> 
	
				</h4></td>
				
				<td>					
					<a href="<?php echo e(route('shirts.edit',$shirt->id)); ?>" class="btn btn-default" style="margin-bottom: 15px;">Edit</a>
					
					
			        <form action="<?php echo e(route('shirts.destroy',$shirt->id)); ?>"  method="POST">
			           	<?php echo e(csrf_field()); ?>

			            <?php echo e(method_field('DELETE')); ?>

			            <input class="btn btn-sm btn-danger" type="submit" value="Delete">
			        </form>
		        </td>
	        </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<h4>No products has been added</h4>	
		<?php endif; ?>	

	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>