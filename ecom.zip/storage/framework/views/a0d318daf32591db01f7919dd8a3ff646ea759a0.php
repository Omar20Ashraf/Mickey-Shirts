<?php $__env->startSection('title','Shirts'); ?>
<?php $__env->startSection('content'); ?>       
<!-- products listing -->
<!-- Latest SHirts -->

<div class="row">
    
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="small-3 columns">
            <div class="item-wrapper">
                <div class="img-wrapper">
                    <a href="<?php echo e(route('cart.addItem',$product->id)); ?>" class="button expanded add-to-cart">
                        Add to Cart
                    </a>
                    <a href="#">
                        <img src="/storage/photos/Products/<?php echo e($product->image); ?>"/>
                    </a>
                </div>
                <a href="<?php echo e(route('shirt',$product->id)); ?>">
                    <h3><?php echo e($product->name); ?> </h3>                          
                </a>

                <h5> $<?php echo e($product->price); ?> </h5>
                                                  
                <p> <?php echo e($product->description); ?> </p>   
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>No Shirts</h3>

    <?php endif; ?>


    <?php $__empty_1 = true; $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="small-3 columns">
            <div class="item-wrapper">
                <div class="img-wrapper">
                    <a href="<?php echo e(route('cart.addItem',$shirt->id)); ?>" class="button expanded add-to-cart">
                        Add to Cart
                    </a>
                    <a href="#">
                        <img src="/storage/photos/shirts/<?php echo e($shirt->image); ?>"/>
                    </a>
                </div>
                <a href="<?php echo e(route('shirt',$shirt->id)); ?>">
                    <h3><?php echo e($shirt->name); ?> </h3>                          
                </a>

                <h5> $<?php echo e($shirt->price); ?> </h5>
                                                  
                <p> <?php echo e($shirt->description); ?> </p>   
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>No Shirts</h3>

    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>        
<?php echo $__env->make('main.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>